export const boradNumbers = []; // הספרים שיש בטבלה
export const oldManMumbers = []; // הגרלות של מספר על ידי לחיצה כפתור
export const strikes = []; // כמות פסילות
